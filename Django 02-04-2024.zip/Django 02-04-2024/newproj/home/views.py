from django.shortcuts import render

# Create your views here.
def first(request):
    if request.method=='GET':
        return render(request,'home/first.html')

    else:
        fullname=request.GET['fullname']
        email=request.GET['email']
        gender=request.GET['gender']
        course=request.GET.getlist('course')
        password=request.GET['password']
        city=request.GET['city']
        
        return render(request,'home/first.html',{'fullname':fullname,'email':email,'gender':gender,'course':course,'password':password,'city':city})











    

